# Cognition Canon

AMOS cognition is modeled as structured orchestration, not literal biological cognition.

Required functions:
- deterministic/explicit logic where applicable;
- structural decomposition;
- multiple hypotheses without premature collapse;
- metacognitive audit;
- causal and scope firewalls;
- provenance-aware evidence evaluation;
- uncertainty-sensitive planning;
- selective repair and revalidation.
