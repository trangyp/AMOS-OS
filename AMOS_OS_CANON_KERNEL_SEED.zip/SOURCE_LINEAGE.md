# Source Lineage

Primary preserved lineages include:
- AMOS_FULL_BRAIN_OS
- AMOS cognition / emotion / super-mind / human-intelligence engines
- Trang Reality Architecture / Trang ∅ Framework corpora
- AMOS_CORE version lineage v3.0 through v4.4

Lineage rule: preserve originals, record ancestry, never treat descendants from one origin as independent confirmation.
