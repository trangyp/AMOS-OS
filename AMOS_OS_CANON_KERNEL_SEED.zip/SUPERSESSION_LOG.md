# Supersession Log

Current AMOS_CORE evolution spine:
v3.0 deterministic logic → v3.1 logic repair → v3.2.1 recursive RSCF/HML → v3.3 governed evolution → v3.4.1 causal lineage → v3.5 epistemic regimes → v3.6 competing hypotheses → v3.7 provenance topology → v3.7.1 Sybil hardening → v3.8 deep provenance → v3.9 persistent provenance → v4.0 MVCC/CAS → v4.1 atomic multi-RSCF → v4.2 causal epoch finality → v4.3 hardened shard-local finalization → v4.4 proof-based coordination avoidance.

Supersession does not delete historical source or benchmark scope.
