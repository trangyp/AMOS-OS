# Kernel Map

- `01_META_LOGIC`: logic, distinction/relation/constraint, law hierarchy.
- `02_COGNITION`: structural reasoning, metacognition, counterfactuals, competing hypotheses.
- `03_CAUSAL`: causal closure/hierarchy/epochs.
- `04_STATE`: system/context/world state.
- `05_MEMORY`: admission, retrieval, compaction, conflict, immune/quarantine.
- `06_RISK_REPAIR`: risk, collapse, homeostasis, repair.
- `07_AUTHORITY`: capability, effect, exposure, commit-time authority.
- `08_PROVENANCE`: provenance graph/topology/Sybil hardening.
- `09_INTEGRATION`: RSCF, GMEF, HML, binding, translation, constraint propagation.
