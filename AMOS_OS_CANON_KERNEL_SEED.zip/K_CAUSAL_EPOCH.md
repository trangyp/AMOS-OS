# K Causal Epoch

Causal epochs provide deterministic finalization boundaries for causally coupled state changes.

v4.2 introduces causal epoch finality; v4.3 hardens adaptive epoch and shard-local finalization; v4.4 permits proof-based coordination avoidance only when independence and closure are demonstrated.
