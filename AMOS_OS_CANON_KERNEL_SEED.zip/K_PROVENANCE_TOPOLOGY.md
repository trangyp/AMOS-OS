# K Provenance Topology

Evidence must retain source identity, ancestry, dependency edges, freshness, regime/environment, falsifiers, and correlation risk where material.

Multiple descendants of one origin are correlated evidence, not independent confirmation. Cycles, missing parents, equivocation, and provenance-Sybil amplification are invalid topology states.
