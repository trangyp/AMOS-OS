# K_RSCF

RSCF is a recursive structured claim/frame unit used to keep claims, premises, dependencies, scope, provenance, competing explanations, falsifiers, and confidence ceilings explicit.

Runtime rule: retrieve and mutate only the dependency closure capable of changing the answer. Coupled RSCFs must finalize atomically when partial commit would violate invariants.
