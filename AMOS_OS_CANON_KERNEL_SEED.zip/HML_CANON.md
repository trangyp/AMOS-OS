# H/M/L Canon

H = macro field, governing law, long horizon.
M = mediating system/body/institution/translation layer.
L = local event/action/token.

Rules:
- L without M becomes noise.
- H without M becomes abstract law.
- M translates H and L.
- Local gain that damages H is scale betrayal.
- Decomposition is recursive: each H, M, and L may itself contain H/M/L.
