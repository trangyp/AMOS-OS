# AMOS Canon Map

Canonical ownership map for AMOS OS.

- Core laws and invariants → `01_CANON/01_CORE_LAWS`
- Universe / HML / persistence canon → `01_CANON/02_UNIVERSE_CANON`
- Cognition / Cognitive Organism / Full Brain canon → `01_CANON/03_COGNITION_CANON`
- Authority / control plane / infrastructure canon → `01_CANON/04_INFRASTRUCTURE_CANON`
- Symbols, units, universal variables → `01_CANON/05_VARIABLE_REGISTRY`
- Terminology and aliases → `01_CANON/06_GLOSSARY`
- Source ancestry and evidence provenance → `01_CANON/07_PROVENANCE`
- Conflict and supersession history → `01_CANON/08_SUPERSESSION`

Current runtime lineage: AMOS_CORE v3.0 → v4.4. Later versions do not erase earlier lineage.
