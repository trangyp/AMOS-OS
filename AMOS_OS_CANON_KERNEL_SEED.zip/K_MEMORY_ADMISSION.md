# K Memory Admission

Ephemeral Code → Persistent Evidence → Validated Knowledge.

Admission requires provenance, scope, environment/regime fit, freshness, dependency links, competing claims, license/IP status where applicable, governance state, and revalidation timing. Documentation claims remain SOURCE_CLAIM until validated.
