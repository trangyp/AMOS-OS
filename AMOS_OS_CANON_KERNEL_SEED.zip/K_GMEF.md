# K_GMEF

GMEF governs evolution/change proposals.

A change is admissible only when it preserves or improves factual support, scope correctness, contradiction visibility, provenance recoverability, causal discipline, safety, efficiency, and user fit. Otherwise reject or roll back.
