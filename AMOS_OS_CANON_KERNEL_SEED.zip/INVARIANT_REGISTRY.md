# Invariant Registry

- `I01_CANON_NONFABRICATION`: missing canon remains a gap.
- `I02_PROVENANCE_PRESERVATION`: claims retain source identity and ancestry.
- `I03_SCOPE_FIREWALL`: no silent generalization outside applicability envelope.
- `I04_CAUSAL_FIREWALL`: association/analogy is not causal proof.
- `I05_COMPETING_PRESERVATION`: unresolved incompatible hypotheses remain COMPETING.
- `I06_CONFIDENCE_CEILING`: conclusions cannot outrun load-bearing premises.
- `I07_SELECTIVE_INVALIDATION`: failed premises invalidate only descendants.
- `I08_GOVERNED_EVOLUTION`: optimization cannot bypass integrity/governance.
- `I09_ATOMIC_REASONING`: coupled multi-RSCF changes finalize consistently.
- `I10_PROOF_FAST_PATH`: local finalization requires demonstrated dependency closure and independence.
