# M SEMANTIC

**Origin architect / steward:** Trang Phan

## Purpose
Define this component's role, interfaces, dependencies, invariants, authority boundary, provenance, tests, failure modes, and recovery semantics.

## Hard boundary
```text
CAPABILITY != AUTHORITY
UNKNOWN/GAP != PASS
```
